import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DataBarangForm extends JFrame {
    private JTextField txtNamaBarang;
    private JTextField txtHarga;
    private JTextField txtJumlah;
    private final JButton btnSimpan;
    private final JTable tableBarang;
    private DefaultTableModel tableModel;

    public DataBarangForm() {
        setTitle("Form Data Barang");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel lblNamaBarang = new JLabel("Nama Barang:");
        lblNamaBarang.setBounds(10, 10, 100, 25);
        add(lblNamaBarang);

        txtNamaBarang = new JTextField();
        txtNamaBarang.setBounds(120, 10, 150, 25);
        add(txtNamaBarang);

        JLabel lblHarga = new JLabel("Harga:");
        lblHarga.setBounds(10, 40, 100, 25);
        add(lblHarga);

        txtHarga = new JTextField();
        txtHarga.setBounds(120, 40, 150, 25);
        add(txtHarga);

        JLabel lblJumlah = new JLabel("Jumlah:");
        lblJumlah.setBounds(10, 70, 100, 25);
        add(lblJumlah);

        txtJumlah = new JTextField();
        txtJumlah.setBounds(120, 70, 150, 25);
        add(txtJumlah);

        btnSimpan = new JButton("Simpan");
        btnSimpan.setBounds(120, 100, 100, 25);
        add(btnSimpan);

        String[] columnNames = {"Nama Barang", "Harga", "Jumlah"};
        tableModel = new DefaultTableModel(columnNames, 0);
        tableBarang = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(tableBarang);
        scrollPane.setBounds(10, 130, 360, 120);
        add(scrollPane);

        btnSimpan.addActionListener((ActionEvent e) -> {
            String namaBarang = txtNamaBarang.getText();
            String harga = txtHarga.getText();
            String jumlah = txtJumlah.getText();
            
            // Menambahkan data ke tabel
            tableModel.addRow(new Object[]{namaBarang, harga, jumlah});
            
            // Mengosongkan field input
            txtNamaBarang.setText("");
            txtHarga.setText("");
            txtJumlah.setText("");
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            DataBarangForm form = new DataBarangForm();
            form.setVisible(true);
        });
    }
}