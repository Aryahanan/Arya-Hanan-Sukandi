package formkasir;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class FormApp {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Form Pendaftaran");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);
        
        // Panel untuk form
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(0, 2));

        // Field input
        panel.add(new JLabel("Nama Lengkap:"));
        JTextField nameField = new JTextField();
        panel.add(nameField);

        panel.add(new JLabel("Alamat:"));
        JTextField addressField = new JTextField();
        panel.add(addressField);

        panel.add(new JLabel("Nomor Telepon:"));
        JTextField phoneField = new JTextField();
        panel.add(phoneField);
        
        panel.add(new JLabel("Email:"));
        JTextField emailField = new JTextField();
        panel.add(emailField);
        
        panel.add(new JLabel("Tanggal Lahir:"));
        JTextField dobField = new JTextField();
        panel.add(dobField);
        
        panel.add(new JLabel("Jenis Kelamin:"));
        JPanel genderPanel = new JPanel();
        JRadioButton male = new JRadioButton("Laki-laki");
        JRadioButton female = new JRadioButton("Perempuan");
        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(male);
        genderGroup.add(female);
        genderPanel.add(male);
        genderPanel.add(female);
        panel.add(genderPanel);

        panel.add(new JLabel("Preferensi Pembayaran:"));
        JPanel paymentPanel = new JPanel();
        JCheckBox cash = new JCheckBox("Tunai");
        JCheckBox creditCard = new JCheckBox("Kartu Kredit");
        JCheckBox bankTransfer = new JCheckBox("Transfer Bank");
        JCheckBox eWallet = new JCheckBox("E-wallet");
        paymentPanel.add(cash);
        paymentPanel.add(creditCard);
        paymentPanel.add(bankTransfer);
        paymentPanel.add(eWallet);
        panel.add(paymentPanel);
        
        // Tombol Submit
        JButton submitButton = new JButton("Submit");
        panel.add(submitButton);
        
        frame.add(panel);
        frame.setVisible(true);

        // Action Listener untuk tombol Submit
        submitButton.addActionListener((ActionEvent e) -> {
            // Ambil nilai dari form
            String name = nameField.getText();
            String address = addressField.getText();
            String phone = phoneField.getText();
            String email = emailField.getText();
            String dob = dobField.getText();
            String gender = male.isSelected() ? "Laki-laki" : "Perempuan";
            String payment = (cash.isSelected() ? "Tunai, " : "") +
                    (creditCard.isSelected() ? "Kartu Kredit, " : "") +
                    (bankTransfer.isSelected() ? "Transfer Bank, " : "") +
                    (eWallet.isSelected() ? "E-wallet, " : "");
            
            // Hapus trailing comma
            if (payment.endsWith(", ")) {
                payment = payment.substring(0, payment.length() - 2);
            }
            
            // Tampilkan informasi ke konsol
            System.out.println("Nama Lengkap: " + name);
            System.out.println("Alamat: " + address);
            System.out.println("Nomor Telepon: " + phone);
            System.out.println("Email: " + email);
            System.out.println("Tanggal Lahir: " + dob);
            System.out.println("Jenis Kelamin: " + gender);
            System.out.println("Preferensi Pembayaran: " + payment);
        });
    }
}