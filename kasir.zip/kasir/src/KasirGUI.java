
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.text.JTextComponent;

public class KasirGUI {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Kasir");
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        JLabel labelNamaKasir = new JLabel("Nama Kasir:");
        labelNamaKasir.setBounds(10, 10, 100, 25);
        frame.add(labelNamaKasir);

        JTextField textNamaKasir = new JTextField();
        textNamaKasir.setBounds(120, 10, 250, 25);
        frame.add(textNamaKasir);

        JLabel labelTanggal = new JLabel("Tanggal Transaksi:");
        labelTanggal.setBounds(10, 40, 150, 25);
        frame.add(labelTanggal);

        JTextField textTanggal = new JTextField();
        textTanggal.setBounds(120, 40, 250, 25);
        frame.add(textTanggal);

        JLabel labelNomorTransaksi = new JLabel("Nomor Transaksi:");
        labelNomorTransaksi.setBounds(10, 70, 150, 25);
        frame.add(labelNomorTransaksi);

        JTextField textNomorTransaksi = new JTextField();
        textNomorTransaksi.setBounds(120, 70, 250, 25);
        frame.add(textNomorTransaksi);

        // Input barang
        for (int i = 0; i < 3; i++) {
            JLabel labelBarang = new JLabel("Nama Barang " + (i + 1) + ":");
            labelBarang.setBounds(10, 100 + (i * 60), 150, 25);
            frame.add(labelBarang);

            JTextField textBarang = new JTextField();
            textBarang.setBounds(120, 100 + (i * 60), 250, 25);
            frame.add(textBarang);

            JLabel labelJumlah = new JLabel("Jumlah:");
            labelJumlah.setBounds(10, 130 + (i * 60), 150, 25);
            frame.add(labelJumlah);

            JTextField textJumlah = new JTextField();
            textJumlah.setBounds(120, 130 + (i * 60), 250, 25);
            frame.add(textJumlah);

            JLabel labelHarga = new JLabel("Harga:");
            labelHarga.setBounds(10, 160 + (i * 60), 150, 25);
            frame.add(labelHarga);

            JTextField textHarga = new JTextField();
            textHarga.setBounds(120, 160 + (i * 60), 250, 25);
            frame.add(textHarga);
        }

        JLabel labelDiskon = new JLabel("Diskon (%):");
        labelDiskon.setBounds(10, 300, 150, 25);
        frame.add(labelDiskon);

        JTextField textDiskon = new JTextField();
        textDiskon.setBounds(120, 300, 250, 25);
        frame.add(textDiskon);

        JButton buttonHitung = new JButton("Hitung Total");
        buttonHitung.setBounds(10, 330, 150, 25);
        frame.add(buttonHitung);

        JTextArea textAreaOutput = new JTextArea();
        textAreaOutput.setBounds(10, 360, 360, 100);
        textAreaOutput.setEditable(false);
        frame.add(textAreaOutput);

        buttonHitung.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double subtotal = 0;
                for (int i = 0; i < 3; i++) {
                    String namaBarang = ((JTextComponent) frame.getContentPane().getComponent(3 + i * 3)).getText();
                    int jumlah = Integer.parseInt(((JTextComponent) frame.getContentPane().getComponent(4 + i * 3)).getText());
                    double harga = Double.parseDouble(((JTextComponent) frame.getContentPane().getComponent(5 + i * 3)).getText());
                    subtotal += jumlah * harga;
                }
                
                double diskonPersen = Double.parseDouble(textDiskon.getText());
                double diskon = (diskonPersen / 100) * subtotal;
                double totalBayar = subtotal double totalBayar = subtotal - diskon;
                
                // Menampilkan hasil di JTextArea
                String output = "----- Rincian Transaksi -----\n";
                output += "Nama Kasir: " + textNamaKasir.getText() + "\n";
                output += "Tanggal Transaksi: " + textTanggal.getText() + "\n";
                output += "Nomor Transaksi: " + textNomorTransaksi.getText() + "\n";
                output += "Subtotal: " + String.format("%.2f", subtotal) + "\n";
                output += "Diskon: " + String.format("%.2f", diskon) + "\n";
                output += "Total Bayar: " + String.format("%.2f", totalBayar) + "\n";
                
                textAreaOutput.setText(output);
            }
        });

        frame.setVisible(true);
    }
}